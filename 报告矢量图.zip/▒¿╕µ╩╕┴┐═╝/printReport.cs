﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Printing;
using System.Drawing;//
using System.Windows.Forms;

//namespace THZYL_CL
//{
public  class printReport
    {
        public  PrintPageEventHandler prr;
        public  void pirntPCReprt()
        {

            //System PrintDialog
            PrintDocument pri = new PrintDocument();
            pri.PrintPage += prr;
            try
            {

                pri.Print();

            }
            catch (Exception ex)
            { }
        pri.PrintPage-= prr;
    }
    public  void showPrintDialog()
    {
        //PrintDialog aaa = new PrintDialog();
        //aaa.UseEXDialog = true;
        THZYL_CL.FormShowPrint aaa = new THZYL_CL.FormShowPrint();
        //aaa.Reset.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;

        /// aaa.Reset();
        if (aaa.ShowDialog() == DialogResult.OK)
        {
            PrintDocument pri = new PrintDocument();
            pri.PrinterSettings = aaa.PrinterSettings;
            pri.PrintPage += prr;
            try
            {

                pri.Print();
            }
            catch (Exception ex)
            { }
            pri.PrintPage -= prr;
        }
    }




}
//}

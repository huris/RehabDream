﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

//namespace Assets.Scripts.NetConnect
//{
public class PrintReportMeth
{
    public PlanOneDay planOneDay;
    public DataXunLian dataXunLian;
    public ZYLOperator zYLOperator;
    public DataRelax dataRelax;
    public DataJieDuan dataJieDuan;
    public SectionResult sectionResult;
    //public string[] exerciseeSceneChi;
    //public string[] relaxSceneChi;
    /// <summary>
    /// 四维雷达图
    /// </summary>
    public Bitmap bit1;
    /// <summary>
    /// 脑波曲线图
    /// </summary>
    public Bitmap bit2;
    /// <summary>
    /// 四维目标雷达图
    /// </summary>
    public Bitmap bit3;
    public void PrintRelax()
    {
        writetofile.Log("PrintReport0");
        printReport printReport1 = new printReport();
        printReport1.prr += new System.Drawing.Printing.PrintPageEventHandler(PrintRealx);
        printReport1.showPrintDialog();
        writetofile.Log("PrintReport2");
        printReport1.prr -= new System.Drawing.Printing.PrintPageEventHandler(PrintRealx);

    }
    public void PrintOneDay1()
    {
        writetofile.Log("PrintOneDay10");
        printReport printReport1 = new printReport();
        printReport1.prr += new System.Drawing.Printing.PrintPageEventHandler(PrintOnedayTrain);
        printReport1.showPrintDialog();
        writetofile.Log("PrintOneDay11");
        printReport1.prr -= new System.Drawing.Printing.PrintPageEventHandler(PrintOnedayTrain);

    }
    public void PrintJD()
    {
        writetofile.Log("PrintJD0");
        printReport printReport1 = new printReport();
        printReport1.prr += new System.Drawing.Printing.PrintPageEventHandler(PrintJieDuan);
        printReport1.showPrintDialog();
        writetofile.Log("PrintJD1");
        printReport1.prr -= new System.Drawing.Printing.PrintPageEventHandler(PrintJieDuan);

    }
    public void PrintSection()
    {
        writetofile.Log("PrintSection0");
        printReport printReport1 = new printReport();
        printReport1.prr += new System.Drawing.Printing.PrintPageEventHandler(PrintSection1);
        printReport1.showPrintDialog();
        writetofile.Log("PrintSection1");
        printReport1.prr -= new System.Drawing.Printing.PrintPageEventHandler(PrintSection1);

    }
    void PrintOnedayTrain(object sender, System.Drawing.Printing.PrintPageEventArgs e)
    {

        try
        {

            System.Drawing.Graphics g = e.Graphics;
            sprintOneDay(g, 830);
            e.HasMorePages = false;
        }
        catch (Exception ex)
        {
            writetofile.Log("printreprot3:" + ex.ToString());
        }
    }
    /// <summary>
    /// 训练报告打印实现
    /// </summary>
    /// <param name="g"></param>
    /// <param name="pagewith"></param>
    public void sprintOneDay(System.Drawing.Graphics g, float pagewith)
    {
        writetofile.Log("sprintOneDay0");
        string[] str1 = { "稳定", "广度", "分配", "转移" };
        float[] ff1 = { Convert.ToSingle(planOneDay.wd_wd), Convert.ToSingle(planOneDay.wd_gd), Convert.ToSingle(planOneDay.wd_fp), Convert.ToSingle(planOneDay.wd_zy) };
        bit1 = drawladar.Getradi(str1, ff1, false);
        bit2 = drawzhexian.Getrect(planOneDay, dataXunLian, true);
        System.Drawing.Font fnt = new System.Drawing.Font("宋体", 22, System.Drawing.FontStyle.Bold);
        float fHeight = 0;
        float fWidStart = 0;
        float fWidEnd = pagewith - 96;
        fHeight += 76;
        fWidStart += 96;

        g.DrawString("训  练  报  告", fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 200, fHeight);
        fHeight += 1.1f * 34 + 2;
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        int fntHeight = 22;
        StringFormat fmt = new StringFormat();
        fmt.Alignment = StringAlignment.Far;
        fmt.LineAlignment = StringAlignment.Near;//右对齐
        fmt.FormatFlags = StringFormatFlags.LineLimit;//自动换行
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        //设定文本打印区域 b是左上角坐标，Size是打印区域（矩形） float mmtopt = 2.835f; 单位换算，毫米*2.835=Point单位
        Rectangle r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fntHeight + 2);

        string str = "时间：" + planOneDay.daytraintime.ToShortDateString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);
        fHeight += fntHeight + 2;


        System.Drawing.Font fntTitle = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Bold);//标题
                                                                                                        //g.DrawString("用户信息：", fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        Pen pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;

        g.DrawString("用户信息：", fntTitle, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "姓名：\t" + zYLOperator.p_name;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "账号：\t" + zYLOperator.p_nickname;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.1f * fntHeight;
        str = "性别：\t" + (zYLOperator.p_sex == 0 ? "男" : "女");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "年龄：\t" + zYLOperator.p_age.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.5f * fntHeight;
        fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        str = "训练结果：";
        g.DrawString(str, fntTitle, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 10;
        str = "得分：" + planOneDay.scor.ToString("0");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight; fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        fnt = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular);
        str = "雷达图";
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "注意力曲线";
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 220, fHeight);
        fHeight += 1.5f * fntHeight;
        float fweithtemp = bit1.Width * 200f / bit1.Height;
        try
        {
            //float[] fff2 = { 1, 2 };
            //drawladar.DrawRadi(str1, ff1, fff2, g, fWidStart, fHeight, 200, 200);

            if (bit1 != null)
                g.DrawImage(bit1, fWidStart, fHeight, fweithtemp, 200f);
        }
        catch (Exception ex)
        {
            writetofile.Log("printreprot4:" + ex.ToString());
        }
        try
        {
            fweithtemp = bit2.Width * 200f / bit2.Height;
            if (bit2 != null)
                g.DrawImage(bit2, fWidStart + 220, fHeight, fweithtemp, 200);
        }
        catch (Exception ex)
        {
            writetofile.Log("printreprot5:" + ex.ToString());
        }
        fHeight += 200;
        fHeight += 10;
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "完成场景：\t\t";
        g.DrawString(str, fntTitle, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "";
        string strch, stren;
        for (int i = 0; i < planOneDay.SectionCount; i++)
        {
            if (planOneDay.Sections[i].sectionType == 0)
            {
                ZYLSection.getRelaxSectionNameByIndex(planOneDay.Sections[i].sectionIndex, out stren, out strch);
                str += strch + "    ";
            }
            else
            {
                ZYLSection.getSectionNameByIndex(planOneDay.Sections[i].sectionIndex, out stren, out strch);
                str += strch + "    ";
            }
        }
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);

        fHeight += 1.5f * fntHeight;
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 0.5f * fntHeight;
        str = "注意力评价";
        g.DrawString(str, fntTitle, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;

        fmt.LineAlignment = StringAlignment.Near;//左对齐
        fmt.Alignment = StringAlignment.Near;

        //设定文本打印区域 b是左上角坐标，Size是打印区域（矩形） float mmtopt = 2.835f; 单位换算，毫米*2.835=Point单位
        r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fntHeight * 4);


        g.DrawString("     " + planOneDay.str1, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);
        fHeight += 3.5f * fntHeight;
        r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fntHeight * 4);
        g.DrawString("     " + planOneDay.str2, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);
        fHeight += 3.5f * fntHeight;
        GC.Collect();
    }


    void PrintRealx(object sender, System.Drawing.Printing.PrintPageEventArgs e)
    {
        try
        {

            System.Drawing.Graphics g = e.Graphics;
            sprintRealx(g, 830);
            e.HasMorePages = false;
        }
        catch (Exception ex)
        {
            writetofile.Log("PrintRealx:" + ex.ToString());
        }
    }
    /// <summary>
    /// 放松报告打印实现
    /// </summary>
    /// <param name="g"></param>
    /// <param name="pagewith"></param>
    void sprintRealx(System.Drawing.Graphics g, float pagewith)
    {
        writetofile.Log("sprintRealx0");
        bit2 = drawzhexian.Getrect(dataRelax.eEDData.meditationdata, true, true, true);
        System.Drawing.Font fnt = new System.Drawing.Font("宋体", 22, System.Drawing.FontStyle.Bold);
        float fHeight = 0;
        float fWidStart = 0;
        float fWidEnd = pagewith - 96;
        fHeight += 76;
        fWidStart += 96;
        g.DrawString("放  松  报  告", fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 200, fHeight);
        fHeight += 34 + 2;
        StringFormat fmt = new StringFormat();
        fmt.Alignment = StringAlignment.Far;
        fmt.LineAlignment = StringAlignment.Near;//右对齐
        fmt.FormatFlags = StringFormatFlags.LineLimit;//自动换行
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        int fntHeight = 22;
        //设定文本打印区域 b是左上角坐标，Size是打印区域（矩形） float mmtopt = 2.835f; 单位换算，毫米*2.835=Point单位
        Rectangle r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fntHeight + 2);

        string str = "时间：" + dataRelax.starttime_re.ToShortDateString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);
        fHeight += 1.1f * fntHeight + 2f;
        Pen pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        System.Drawing.Font fntTitle = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        g.DrawString("用户信息：", fntTitle, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "姓名：\t" + zYLOperator.p_name;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "账号：\t" + zYLOperator.p_nickname;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.1f * fntHeight;
        str = "性别：\t" + (zYLOperator.p_sex == 0 ? "男" : "女");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "年龄：\t" + zYLOperator.p_age.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.5f * fntHeight;
        fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;

        str = "放松结果：";
        g.DrawString(str, fntTitle, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight; fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);

        str = "放松曲线图";
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        float fweithtemp;

        try
        {
            fweithtemp = bit2.Width * 200f / bit2.Height;
            if (bit2 != null)
                g.DrawImage(bit2, fWidStart, fHeight, fweithtemp, 200);
        }
        catch (Exception ex)
        {
            writetofile.Log("sprintRealx1:" + ex.ToString());
        }
        fHeight += 200;
        fHeight += 10;
        str = "最    佳：\t" + dataRelax.minNum.ToString("0.0");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "平均值：\t" + dataRelax.average.ToString("0.0");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "深度放松：\t" + dataRelax.percent.ToString("0.0") + "%";
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        fHeight += 1.5f * fntHeight;
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 1.5f * fntHeight;

        str = "放松评语：\t\t";
        g.DrawString(str, fntTitle, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        writetofile.Log("sprintRealx2:");

        fmt.LineAlignment = StringAlignment.Near;//左对齐
        fmt.Alignment = StringAlignment.Near;

        //设定文本打印区域 b是左上角坐标，Size是打印区域（矩形） float mmtopt = 2.835f; 单位换算，毫米*2.835=Point单位
        r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fntHeight * 4);
        g.DrawString("     " + dataRelax.strPingYu, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);


        writetofile.Log("sprintRealxend:");
        GC.Collect();
    }

    void PrintJieDuan(object sender, System.Drawing.Printing.PrintPageEventArgs e)
    {
        try
        {

            System.Drawing.Graphics g = e.Graphics;
            sprintRange(g, 830);
            e.HasMorePages = false;
        }
        catch (Exception ex)
        {
            writetofile.Log("PrintJieDuan:" + ex.ToString());
        }
    }
    /// <summary>
    /// 阶段报告打印实现
    /// </summary>
    /// <param name="g"></param>
    /// <param name="pagewith"></param>
    void sprintRange(System.Drawing.Graphics g, float pagewith)
    {
        writetofile.Log("sprintRange0");
        string[] str1 = { "稳定", "广度", "分配", "转移" };
        float[] ff1 = { Convert.ToSingle(dataJieDuan.fWDPr), Convert.ToSingle(dataJieDuan.fGDPr), Convert.ToSingle(dataJieDuan.fFPPr), Convert.ToSingle(dataJieDuan.fZYPr) };
        bit1 = drawladar.Getradi(str1, ff1, false);
        float[] ff2 = { Convert.ToSingle(dataJieDuan.fWDAf), Convert.ToSingle(dataJieDuan.fGDAf), Convert.ToSingle(dataJieDuan.fFPAf), Convert.ToSingle(dataJieDuan.fZYAf) };
        bit3 = drawladar.Getradi(str1, ff2, true);
        bit2 = drawzhexian.Getrect(dataJieDuan.averageAttention, 21);
        System.Drawing.Font fnt = new System.Drawing.Font("宋体", 22, System.Drawing.FontStyle.Bold);
        float fHeight = 0;
        float fWidStart = 0;
        float fWidEnd = pagewith - 96;
        fHeight += 76;
        fWidStart += 96;
        g.DrawString("阶  段  报  告", fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 200, fHeight);
        fHeight += 1.1f * 34 + 2;
        int fntHeight = 22;
        StringFormat fmt = new StringFormat();
        fmt.Alignment = StringAlignment.Far;
        fmt.LineAlignment = StringAlignment.Near;//右对齐
        fmt.FormatFlags = StringFormatFlags.LineLimit;//自动换行
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        //设定文本打印区域 b是左上角坐标，Size是打印区域（矩形） float mmtopt = 2.835f; 单位换算，毫米*2.835=Point单位
        Rectangle r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fntHeight + 2);

        string str = "时间：" + dataJieDuan.start.ToShortDateString() + "-" + dataJieDuan.end.ToShortDateString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);
        fHeight += fntHeight + 2;

        Pen pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        System.Drawing.Font fnt2 = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Bold);
        System.Drawing.Font fnt3 = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular);
        g.DrawString("用户信息：", fnt2, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);

        fHeight += 1.5f * fntHeight;
        str = "姓名：\t" + zYLOperator.p_name;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "账号：\t" + zYLOperator.p_nickname;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.1f * fntHeight;
        str = "性别：\t" + (zYLOperator.p_sex == 0 ? "男" : "女");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "年龄：\t" + zYLOperator.p_age.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.5f * fntHeight;
        fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        str = "训练标签：" + dataJieDuan.label1;
        g.DrawString(str, fnt2, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight; fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        fnt = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular);
        str = "雷达图";
        g.DrawString(str, fnt2, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        float fweithtemp = bit1.Width * 200f / bit1.Height;
        try
        {
            if (bit1 != null)
                g.DrawImage(bit1, fWidStart, fHeight, fweithtemp, 200f);
        }
        catch (Exception ex)
        {
            writetofile.Log("sprintRange1:" + ex.ToString());
        }

        try
        {
            fweithtemp = bit3.Width * 200f / bit3.Height;
            if (bit3 != null)
                g.DrawImage(bit3, fWidStart + 330, fHeight, fweithtemp, 200);
        }
        catch (Exception ex)
        {
            writetofile.Log("sprintRange2:" + ex.ToString());
        }
        fHeight += 200;
        fHeight += 10;
        str = "训练前";
        g.DrawString(str, fnt3, new SolidBrush(System.Drawing.Color.Black), fWidStart + 50, fHeight);
        str = "训练后";
        g.DrawString(str, fnt3, new SolidBrush(System.Drawing.Color.Black), fWidStart + 320, fHeight);
        fHeight += 1.5f * fntHeight;
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 1.5f * fntHeight;
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Bold);
        str = "注意力21天变化图：\t\t";
        g.DrawString(str, fnt2, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        try
        {
            fweithtemp = bit2.Width * 200f / bit2.Height;
            if (bit2 != null)
                g.DrawImage(bit2, fWidStart, fHeight, fweithtemp, 200);
        }
        catch (Exception ex)
        {
            writetofile.Log("sprintRange3:" + ex.ToString());
        }
        fHeight += 200 + 1.5f * fntHeight;
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 0.5f * fntHeight;
        str = "总结：";
        g.DrawString(str, fnt2, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "本阶段训练共完成了：";
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "训练场景：\t" + dataJieDuan.trainSectionCount.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "放松场景：\t" + dataJieDuan.relaxSectionCount.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 220, fHeight);
        fHeight += 1.1f * fntHeight;
        str = "最佳注意力：\t" + dataJieDuan.fBestAttention.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "最佳放松：\t" + dataJieDuan.fBestRelax.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 220, fHeight);
        fHeight += 1.1f * fntHeight;
        str = "平均注意力：\t" + dataJieDuan.fAverAttention.ToString("0.0");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "平均放松：\t" + dataJieDuan.fAverRelax.ToString("0.0");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 220, fHeight);
        fHeight += 1.1f * fntHeight;
        GC.Collect();
    }


    void PrintSection1(object sender, System.Drawing.Printing.PrintPageEventArgs e)
    {
        try
        {

            System.Drawing.Graphics g = e.Graphics;
            sprintSection(g, 830);
            e.HasMorePages = false;
        }
        catch (Exception ex)
        {
            writetofile.Log("PrintJieDuan:" + ex.ToString());
        }
    }
    /// <summary>
    /// 场景报告打印实现
    /// </summary>
    /// <param name="g"></param>
    /// <param name="pagewith"></param>
    void sprintSection(System.Drawing.Graphics g, float pagewith)
    {
        writetofile.Log("sprintRealx0");
        bit2 = drawzhexian.Getrect(sectionResult.eEDData.attentiondata, true, false, false);
        System.Drawing.Font fnt = new System.Drawing.Font("宋体", 22, System.Drawing.FontStyle.Bold);
        float fHeight = 0;
        float fWidStart = 0;
        float fWidEnd = pagewith - 96;
        int fntHeight = 22;
        fHeight += 76;
        fWidStart += 96;
        g.DrawString("场  景  报  告", fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 200, fHeight);
        fHeight += 34 + 2;
        StringFormat fmt = new StringFormat();
        fmt.Alignment = StringAlignment.Far;
        fmt.LineAlignment = StringAlignment.Near;//右对齐
        fmt.FormatFlags = StringFormatFlags.LineLimit;//自动换行
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        //设定文本打印区域 b是左上角坐标，Size是打印区域（矩形） float mmtopt = 2.835f; 单位换算，毫米*2.835=Point单位
        Rectangle r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fntHeight + 2);

        string str = "时间：" + sectionResult.testTime.ToLongTimeString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);
        fHeight += 1.1f * fntHeight + 2f;
        Pen pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Regular);
        g.DrawString("用户信息：", fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        str = "姓名：\t" + zYLOperator.p_name;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "账号：\t" + zYLOperator.p_nickname;
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.1f * fntHeight;
        str = "性别：\t" + (zYLOperator.p_sex == 0 ? "男" : "女");
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        str = "年龄：\t" + zYLOperator.p_age.ToString();
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart + 330, fHeight);
        fHeight += 1.5f * fntHeight;
        fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);
        g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        fHeight += 10;
        fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Bold);
        str = "场景结果：";
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight; fHeight += 10;
        pen = new Pen(System.Drawing.Color.Black, 2);
        str = "场景名称：" + (sectionResult.str_secChineName.Split(' '))[0];
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight; fHeight += 10;
        str = "脑电曲线图";
        g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        fHeight += 1.5f * fntHeight;
        float fweithtemp;

        try
        {
            fweithtemp = bit2.Width * 200f / bit2.Height;
            if (bit2 != null)
                g.DrawImage(bit2, fWidStart, fHeight, fweithtemp, 200);
        }
        catch (Exception ex)
        {
            writetofile.Log("printreprot5:" + ex.ToString());
        }
        //fHeight += 200;
        //fHeight += 10;
        //fHeight += 1.5f * fnt.Height;
        //g.DrawLine(pen, fWidStart, fHeight, fWidEnd, fHeight);
        //fHeight += 1.5f * fnt.Height;
        //fnt = new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Bold);
        //str = "放松评语：\t\t";
        //g.DrawString(str, fnt, new SolidBrush(System.Drawing.Color.Black), fWidStart, fHeight);
        //fHeight += 1.5f * fnt.Height;


        //fmt.LineAlignment = StringAlignment.Near;//左对齐
        //fmt.Alignment = StringAlignment.Near;

        ////设定文本打印区域 b是左上角坐标，Size是打印区域（矩形） float mmtopt = 2.835f; 单位换算，毫米*2.835=Point单位
        //r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fnt.Height * 4);
        //g.DrawString("     " + dataRelax.strPingYu, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);

        //fHeight += 3.5f * fnt.Height;
        //r = new Rectangle(Convert.ToInt32(fWidStart), Convert.ToInt32(fHeight), Convert.ToInt32(fWidEnd - fWidStart), fnt.Height * 4);
        //g.DrawString("     " + planOneDay.str2, fnt, new SolidBrush(System.Drawing.Color.Black), r, fmt);
        //fHeight += 3.5f * fnt.Height;
        GC.Collect();
    }
}
//}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;

//namespace THZYL_CL
//{
    public static class drawladar
    {
        static float mw = 1200;
        static float mh = 1200;
        static string[] strName;
        static float mcount = 4; //边数
        static int radiocount = 5;//共有几层同心圆
        static float mcenter = mw * 0.5f; //中心点
        static float mradius = mcenter - 180; //半径(减去的值用于给绘制的文本留空间)
        static double mangle = (Math.PI * 2) / mcount; //角度
        static Graphics graphics = null;
        static int mpointradius = 5; // 各个维度分值圆点的半径 
        static int textfontsize = 48;  //顶点文字大小 px
        const string textfontfamily = "microsoft yahei"; //顶点字体
        static Color linecolor = Color.Green;
        static Color fillcolor = Color.FromArgb(128, 255, 0, 0);
        static Color fontcolor = Color.Black;
        public static void show(string[] str, float[] fff)
        {
            //strName = str;
            //mcount = str.Length;
            //Bitmap img = new Bitmap((int)mw, (int)mh);
            //graphics = Graphics.FromImage(img);
            //graphics.Clear(Color.White);
            //img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\0.png", ImageFormat.Png);
            //// img.Save(AppDomain.CurrentDomain.BaseDirectory+"//radar//0.png", ImageFormat.Png);
            //drawpolygon(graphics);
            //img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\1.png", ImageFormat.Png);
            //drawlines(graphics);
            //img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\2.png", ImageFormat.Png);
            //drawtext(graphics);
            //img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\3.png", ImageFormat.Png);
            //drawregion(graphics, fff);
            //img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\4.png", ImageFormat.Png);
            //drawcircle(graphics, fff);
            //img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\5.png", ImageFormat.Png);
            //img.Dispose();
            //graphics.Dispose();
        }
        public static Bitmap Getradi(string[] str, float[] fff, float[] fff2)
        {
            strName = str;
            Bitmap img = new Bitmap((int)mw, (int)mh);
            graphics = Graphics.FromImage(img);
            graphics.Clear(Color.White);

            drawpolygon(graphics);

            drawlines(graphics);

            drawtext(graphics);
            Pen p = new Pen(Color.Blue, 2);
            drawregion(graphics, fff, p, false);
            p = new Pen(Color.Red, 2);
            drawregion(graphics, fff2, p, true);

            drawcircle(graphics, fff);
            drawcircle(graphics, fff2);

            return img;
        }

    public static void DrawRadi(string[] str, float[] fff, float[] fff2, Graphics g,float ffromx,float ffromy,float fwidth,float fHeight)
    {
        graphics = g;
        graphics.TranslateTransform(ffromx, ffromy);
        drawpolygon(graphics);

        drawlines(graphics);

        drawtext(graphics);
        Pen p = new Pen(Color.Blue, 2);
        drawregion(graphics, fff, p, false);
        if (fff2.Length > 3)
        {
            p = new Pen(Color.Red, 2);
            drawregion(graphics, fff2, p, true);
        }
        drawcircle(graphics, fff);
        if (fff2.Length > 3)
        {
            drawcircle(graphics, fff2);
        }
        graphics.TranslateTransform(ffromx, ffromy);
    }

        
        public static Bitmap Getradi(string[] str, float[] fff,bool bMubiao)
        {
            strName = str;
            Bitmap img = new Bitmap((int)mw, (int)mh);
            graphics = Graphics.FromImage(img);
            graphics.Clear(Color.White);

            drawpolygon(graphics);

            drawlines(graphics);

            drawtext(graphics);
            Pen p = new Pen(Color.Blue, 2);
            drawregion(graphics, fff, p, bMubiao);


            drawcircle(graphics, fff);

           // img.Save(@"F:\4.Png", ImageFormat.Png);
            return img;
        }
        public static void show(string[] str, float[] fff, float[] fff2)
        {
            strName = str;
            mcount = str.Length;
            Bitmap img = new Bitmap((int)mw, (int)mh);
            graphics = Graphics.FromImage(img);
            graphics.Clear(Color.White);
            img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\0.png", ImageFormat.Png);
            // img.Save(AppDomain.CurrentDomain.BaseDirectory+"//radar//0.png", ImageFormat.Png);
            drawpolygon(graphics);
            img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\1.png", ImageFormat.Png);
            drawlines(graphics);
            img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\2.png", ImageFormat.Png);
            drawtext(graphics);
            img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\3.png", ImageFormat.Png);
            Pen p = new Pen(Color.Blue, 2);

            drawregion(graphics, fff, p, false);
            p = new Pen(Color.Red, 2);
            drawregion(graphics, fff2, p, true);
            img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\4.png", ImageFormat.Png);
            drawcircle(graphics, fff);
            drawcircle(graphics, fff2);
            img.Save(@"F:\Project\AttentionTrainingSystem\WindowsFormsApp1\WindowsFormsApp1\bin\Debug\111\5.png", ImageFormat.Png);
            img.Dispose();
            graphics.Dispose();
        }

        private static void drawpolygon(Graphics ctx)
        {
            var r = mradius / radiocount; //单位半径
            Pen pen = new Pen(linecolor);
            //画6个圈
            int i = 0;

            List<PointF> points;


            getcirclepoints(out points, 2, r);
            ctx.FillPolygon(new SolidBrush(Color.WhiteSmoke), points.ToArray());
            ctx.DrawPolygon(pen, points.ToArray());
            getcirclepoints(out points, 1, r);
            ctx.FillPolygon(new SolidBrush(Color.White), points.ToArray());
            ctx.DrawPolygon(pen, points.ToArray());
            getcirclepoints(out points, 3, r);
            ctx.DrawPolygon(pen, points.ToArray());
            getcirclepoints(out points, 1, r);
            ctx.DrawPolygon(pen, points.ToArray());
            getcirclepoints(out points, 4, r);
            ctx.DrawPolygon(pen, points.ToArray());

            ctx.Save();
        }
        private static void getcirclepoints(out List<PointF> points, int i, float r)
        {
            points = new List<PointF>();
            var currr = r * (i + 1); //当前半径
                                     //画6条边
            for (var j = 0; j < mcount; j++)
            {
                var x = (float)(mcenter + currr * Math.Cos(mangle * j));
                var y = (float)(mcenter + currr * Math.Sin(mangle * j));
                points.Add(new PointF(x, y));
            }
        }
        //顶点连线
        private static void drawlines(Graphics ctx)
        {
            for (var i = 0; i < mcount; i++)
            {
                var x = (float)(mcenter + mradius * Math.Cos(mangle * i));
                var y = (float)(mcenter + mradius * Math.Sin(mangle * i));
                ctx.DrawLine(new Pen(linecolor), new PointF(mcenter, mcenter), new PointF(x, y));
                //break;
            }
            ctx.Save();
        }
        //绘制文本
        private static void drawtext(Graphics ctx)
        {
            var fontsize = textfontsize;//mcenter / 12;
            Font font = new Font(textfontfamily, fontsize, FontStyle.Regular);
            int i = 0;
            for (int j = 0; j < strName.Length; j++)
            {
                var x = (float)(mcenter + mradius * Math.Cos(mangle * i));
                var y = (float)(mcenter + mradius * Math.Sin(mangle * i) - fontsize);
                if (mangle * i > 0 && mangle * i <= Math.PI / 2)
                {
                    ctx.DrawString(strName[j], font, new SolidBrush(fontcolor), x - ctx.MeasureString(strName[j], font).Width * 0.5f, y + fontsize/* y + fontsize*/);
                }
                else if (mangle * i > Math.PI / 2 && mangle * i <= Math.PI)
                {
                    ctx.DrawString(strName[j], font, new SolidBrush(fontcolor), x - ctx.MeasureString(strName[j], font).Width, y /*y + fontsize*/);
                }
                else if (mangle * i > Math.PI && mangle * i <= Math.PI * 3 / 2)
                {
                    ctx.DrawString(strName[j], font, new SolidBrush(fontcolor), x - ctx.MeasureString(strName[j], font).Width / 2, y - fontsize * 0.5f - 10);//
                }
                else if (mangle * i > Math.PI * 3 / 2)
                {
                    ctx.DrawString(strName[j], font, new SolidBrush(fontcolor), x - ctx.MeasureString(strName[j], font).Width * 0.5f, y - fontsize * 0.5f);
                }
                else
                {
                    ctx.DrawString(strName[j], font, new SolidBrush(fontcolor), x, y /* y + fontsize*/);
                }
                i++;
            }
            ctx.Save();
        }
        //绘制数据区域
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="floa"></param>
        /// <param name="p"></param>
        /// <param name="second">0,只有原始值，2</param>
        private static void drawregion(Graphics ctx, float[] floa, Pen p, bool second)
        {
            int i = 0;
            List<PointF> points = new List<PointF>();
            for (int j = 0; j < strName.Length; j++)
            {
                var x = (float)(mcenter + mradius * Math.Cos(mangle * i) * floa[j] / 100);
                var y = (float)(mcenter + mradius * Math.Sin(mangle * i) * floa[j] / 100);
                points.Add(new PointF(x, y));
                //ctx.drawarc(new pen(linecolor), x, y, r, r, 0, (float)math.pi * 2);
                i++;
            }
            {
                var x = (float)(mcenter + mradius * Math.Cos(mangle * i) * floa[0] / 100);
                var y = (float)(mcenter + mradius * Math.Sin(mangle * i) * floa[0] / 100);
                points.Add(new PointF(x, y));

            }//graphicspath path = new graphicspath();

            ctx.DrawLines(p, points.ToArray());
            var fontsize = textfontsize;//mcenter / 12;
            Font font = new Font(textfontfamily, fontsize, FontStyle.Regular);
             int fntHeight = 85;
            float fstrstart = 0;
            if (second)
            {
                ctx.DrawLine(p, mw * 3 / 4 - fntHeight * 2, fstrstart + 0.5f * fntHeight, mw * 3 / 4, fstrstart + 0.5f * fntHeight);
                ctx.DrawString("目标值", font, new SolidBrush(p.Color), mw * 3 / 4, fstrstart);
            }
            else
            {
                ctx.DrawLine(p, mw * 3 / 4 - fntHeight * 2, fstrstart + 1.5f * fntHeight, mw * 3 / 4, fstrstart + 1.5f * fntHeight);
                ctx.DrawString("原始值", font, new SolidBrush(p.Color), mw * 3 / 4, fstrstart + fntHeight);
            }
            ctx.Save();
        }


        private static void drawcircle(Graphics ctx, float[] floa)
        {
            //var r = mcenter / 18;
            var r = mpointradius;
            int i = 0;
            for (int j = 0; j < strName.Length; j++)
            {
                var x = (float)(mcenter + mradius * Math.Cos(mangle * i) * floa[j] / 100);
                var y = (float)(mcenter + mradius * Math.Sin(mangle * i) * floa[j] / 100);
                ctx.FillPie(new SolidBrush(fillcolor), x - r, y - r, r * 2, r * 2, 0, 360);
                //ctx.drawarc(new pen(linecolor), x, y, r, r, 0, (float)math.pi * 2);
                i++;
            }
            ctx.Save();
        }
    }

    public static class drawzhexian
    {
    public static Bitmap Getrect(double[] fdata, bool sec,bool isrealx,bool Max75)
    {
        int Xrange = 1000, Yrange = 500;
        if (isrealx)
            Xrange = 1250;
        Font font = new Font("宋体", 18, FontStyle.Regular);
        Bitmap img = new Bitmap(Xrange, Yrange);
        int fntHeight = 28;
        float f_ZeroX = fntHeight * 5, f_ZeroY = Yrange - fntHeight * 3;
        float f_Xlength = Xrange - 2 * f_ZeroX, f_Ylength = Yrange - fntHeight * 6;
        Graphics graphics = Graphics.FromImage(img);

        graphics.Clear(Color.White);
        Pen pen = new Pen(Color.Black);
        float f = f_ZeroY;
        int iLenght = fdata.Length;
        int xiabiaocount = 6;
        int xiabiao = iLenght / xiabiaocount;
        float fEachpoint = f_Xlength / iLenght;
        bool bMin = false;
        float fxshift = fntHeight;
        float fyshift = fntHeight;
        float xf = f_ZeroX - fxshift;
        #region  画柱状图
        Color FColor = Color.White; //颜色1
        Color TColor = Color.Red;  //颜色2

        fxshift = f_Xlength / (iLenght - 1);
        xf = f_ZeroX;
        f = f_ZeroY;
        float fff = 100f;
        if (Max75)
            fff = 75f;
        fyshift = f_Ylength / fff;
        List<PointF> points = new List<PointF>();
        List<PointF> points1 = new List<PointF>();
        pen = new Pen(Color.Empty);
        PointF p1 = new PointF(xf, f);
        PointF p2 = new PointF(xf, f - f_Ylength);
        //PointF p3 = new PointF(xf, f - 35 * fyshift);
        Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, TColor);  //实例化刷子，第一个参数指示上色区域，第二个和第三个参数分别渐变颜色的开始和结束，第四个参数表示颜色的方向。
        Brush b2 = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, Color.Gray);
        float fnow, fnext;
        fnow = Convert.ToSingle(fdata[0]>fff?fff: fdata[0]);
        float fgrayLevel = 35f;
        if (isrealx)
            fgrayLevel = 25f;
        for (int i = 0; i < iLenght - 1; i++)
        {
            points1.Add(new PointF(xf, Convert.ToSingle(f - fnow * fyshift)));
            fnext = Convert.ToSingle(fdata[i+1] > fff ? fff : fdata[i+1]);
            if ((fnow - fgrayLevel) * (fnext - fgrayLevel) < 0)
            {
                float ftemp = Convert.ToSingle(fxshift * (fgrayLevel - fnow) / (fnext - fnow));
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fnow * fyshift)));
                points.Add(new PointF(xf + ftemp, Convert.ToSingle(f - fgrayLevel * fyshift)));
                points.Add(new PointF(xf + ftemp, f));
                if (fnow < fgrayLevel)
                    graphics.FillPolygon(b2, points.ToArray());
                else
                    graphics.FillPolygon(b, points.ToArray());
                points = new List<PointF>();
                points.Add(new PointF(xf + ftemp, f));
                points.Add(new PointF(xf + ftemp, Convert.ToSingle(f - fgrayLevel * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fnext * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                if (fnext < fgrayLevel)
                    graphics.FillPolygon(b2, points.ToArray());
                else
                    graphics.FillPolygon(b, points.ToArray());
            }
            else if (fnext < fgrayLevel)
            {
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fnow * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fnext * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                graphics.FillPolygon(b2, points.ToArray());
            }
            else
            {
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fnow * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fnext * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                graphics.FillPolygon(b, points.ToArray());
            }
            xf += fxshift;
            fnow= fnext ;
        }
        pen = new Pen(Color.Black);
        graphics.DrawLines(pen, points1.ToArray());
        #endregion
        #region 坐标轴

        graphics.DrawLine(pen, f_ZeroX, f_ZeroY, f_ZeroX, f_ZeroY - f_Ylength);
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
        float fwidthOneowr = graphics.MeasureString("神", font).Width+2;
        if (isrealx)
        {
            if (Max75)
            {
                f -= 25f * fyshift;
                graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
                graphics.DrawString("25", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
                f -= 25f * fyshift;
                //graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
                //graphics.DrawString("50", font, Brushes.Black, f_ZeroX - font.Height * 2, f - font.Height / 2);
                f -= 25f * fyshift;
                graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
                graphics.DrawString("75", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
                f = f_ZeroY - f_Ylength * 0.83f - fntHeight * 0.4f;
                graphics.DrawString("未", font, Brushes.Red, f_ZeroX - fwidthOneowr, f);
                graphics.DrawString("放", font, Brushes.Red, f_ZeroX - fwidthOneowr, f + fntHeight+3);
                graphics.DrawString("松", font, Brushes.Red, f_ZeroX - fwidthOneowr, f + fntHeight * 2+6);
                f = f_ZeroY - f_Ylength * 0.21f - fntHeight * 0.4f;
                graphics.DrawString("放", font, Brushes.Blue, f_ZeroX - fwidthOneowr, f);
                graphics.DrawString("松", font, Brushes.Blue, f_ZeroX - fwidthOneowr, f + fntHeight+3);
            }
            else
            {
                f -= 25f * fyshift;
                graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
                graphics.DrawString("25", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
                f -= 25f * fyshift;
                //graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
                //graphics.DrawString("50", font, Brushes.Black, f_ZeroX - font.Height * 2, f - font.Height / 2);
                f -= 50f * fyshift;
                graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
                graphics.DrawString("100", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
                f = f_ZeroY - f_Ylength * 0.83f - fntHeight * 0.4f;

                graphics.DrawString("未", font, Brushes.Red, f_ZeroX - fwidthOneowr, f);
                graphics.DrawString("放", font, Brushes.Red, f_ZeroX - fwidthOneowr, f + fntHeight+3);
                graphics.DrawString("松", font, Brushes.Red, f_ZeroX - fwidthOneowr, f + fntHeight * 2+6);
                f = f_ZeroY - f_Ylength * 0.2f - fntHeight * 0.4f;
                graphics.DrawString("放", font, Brushes.Blue, f_ZeroX - fwidthOneowr, f);
                graphics.DrawString("松", font, Brushes.Blue, f_ZeroX - fwidthOneowr, f + fntHeight+3);
            }
        }
        else
        {
            f -= f_Ylength * 0.35f;
            graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
            graphics.DrawString("35", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
            f -= f_Ylength * 0.3f;
            graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
            graphics.DrawString("65", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
            f -= f_Ylength * 0.35f;
            graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
            graphics.DrawString("100", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
            f = f_ZeroY - f_Ylength * 0.18f - fntHeight * 0.4f;
            graphics.DrawString("走神", font, Brushes.Blue, f_ZeroX - graphics.MeasureString("走神", font).Width-2, f);
            f = f_ZeroY - f_Ylength * 0.53f - fntHeight * 0.4f;
            graphics.DrawString("一般", font, Brushes.Orange, f_ZeroX - graphics.MeasureString("一般", font).Width - 2, f);
            f = f_ZeroY - f_Ylength * 0.83f - fntHeight * 0.4f;
            graphics.DrawString("忘我", font, Brushes.Red, f_ZeroX - graphics.MeasureString("忘我", font).Width - 2, f);
        }
        pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

        if (xiabiao > 60)
        {
            bMin = true;
            xiabiao = Convert.ToInt32(Math.Ceiling(xiabiao / 60f) * 60);
            xiabiaocount = iLenght / xiabiao;
        }
        if (Math.Abs(xiabiao * xiabiaocount - iLenght) > 0 && Math.Abs(xiabiao * xiabiaocount - iLenght) < xiabiao / 3)
            xiabiaocount--;


        f = f_ZeroY + fntHeight;
        xf = f_ZeroX;
        //graphics.DrawLine(pen, xf + fxshift, f_ZeroY, xf + fxshift, f_ZeroY + 3);
        //graphics.DrawString("0", font, Brushes.Red, xf , f);
        for (int i = 0; i <= xiabiaocount; i++)
        {

            int aa = bMin ? i * xiabiao / 60 : i * xiabiao;
            aa = sec ? aa : aa / 2;
            graphics.DrawLine(pen, xf, f_ZeroY, xf, f_ZeroY + 3);
            graphics.DrawString(aa.ToString(), font, Brushes.Red, xf- graphics.MeasureString(aa.ToString(), font).Width/2, f - fntHeight *2/ 3);
            xf += f_Xlength * xiabiao / iLenght;
        }
        #endregion
        pen = new Pen(Color.Black);
        //img.Save(@"F:\5.png", ImageFormat.Png);
        graphics.Dispose();
        return img;
    }
    static int relaxindex = 0; static int trsecindex = 0;static int secindex = 0;static int iDataindex = 0;
    static void getcurrentandnextpoint(PlanOneDay planOneDay, DataXunLian dataXunLian, out float datanow)
    {
        if (planOneDay.Sections[secindex].sectionType == 0)
        {
            if (iDataindex < dataXunLian.dataRelaxes[relaxindex].eEDData.attentiondata.Length - 1)
            {
                datanow = Convert.ToSingle(dataXunLian.dataRelaxes[relaxindex].eEDData.attentiondata[iDataindex++]);
            }
            else
            {
                datanow = Convert.ToSingle(dataXunLian.dataRelaxes[relaxindex].eEDData.attentiondata[iDataindex++]);
                secindex++;
                relaxindex++;
                iDataindex = 0;
            }
        }
        else
        {
            if (iDataindex < dataXunLian.sectionResult1[trsecindex].eEDData.attentiondata.Length - 1)
            {
                datanow = Convert.ToSingle(dataXunLian.sectionResult1[trsecindex].eEDData.attentiondata[iDataindex++]);
            }
            else
            {
                datanow = Convert.ToSingle(dataXunLian.sectionResult1[trsecindex].eEDData.attentiondata[iDataindex++]);
                secindex++;
                trsecindex++;
                iDataindex = 0;
            }
           
        }
    }
    public static Bitmap Getrect(PlanOneDay planOneDay,DataXunLian dataXunLian, bool sec)
    {
        int Xrange = 1000, Yrange = 500;
        Font font = new Font("宋体", 18, FontStyle.Regular);
        Bitmap img = new Bitmap(Xrange, Yrange);
        int fntHeight = 28;
        float f_ZeroX = fntHeight * 5, f_ZeroY = Yrange - fntHeight * 3;
        float f_Xlength = Xrange - 2 * f_ZeroX, f_Ylength = Yrange - fntHeight * 6;
        Graphics graphics = Graphics.FromImage(img);

        graphics.Clear(Color.White);
        Pen pen = new Pen(Color.Black);
        float f = f_ZeroY;
        int iLenght = 0;
        relaxindex = 0; trsecindex = 0; secindex = 0;
        for (int i = 0; i < planOneDay.SectionCount; i++)
        {
            if (planOneDay.Sections[i].sectionType == 0)
                iLenght += dataXunLian.dataRelaxes[relaxindex++].eEDData.attentiondata.Length;
            else 
                iLenght += dataXunLian.sectionResult1[trsecindex++].eEDData.attentiondata.Length;
        }
        int xiabiaocount = 6;
        int xiabiao = iLenght / xiabiaocount;
        float fEachpoint = f_Xlength / iLenght;
        bool bMin = false;
        float fxshift = fntHeight;
        float fyshift = fntHeight;
        float xf = f_ZeroX - fxshift;
        #region  画柱状图
        Color FColor = Color.White; //颜色1
        Color TColor = Color.Red;  //颜色2

        fxshift = f_Xlength / (iLenght - 1);
        xf = f_ZeroX;
        f = f_ZeroY;
        float fff = 100f;
        fyshift = f_Ylength / fff;
        List<PointF> points = new List<PointF>();
        List<PointF> points1 = new List<PointF>();
        pen = new Pen(Color.Empty);
        PointF p1 = new PointF(xf, f);
        PointF p2 = new PointF(xf, f - f_Ylength);
        PointF p3 = new PointF(xf, f - 35 * fyshift);
        Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, TColor);  //实例化刷子，第一个参数指示上色区域，第二个和第三个参数分别渐变颜色的开始和结束，第四个参数表示颜色的方向。
        Brush b2 = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, Color.Gray);
        relaxindex = 0; trsecindex = 0; secindex = 0; iDataindex = 0;
        float fdatanow = 0, fdatanext = 0;
        getcurrentandnextpoint(planOneDay, dataXunLian, out fdatanow);
        for (int i = 0; i < iLenght - 1; i++)
        {
            // p1 = new Point(Convert.ToInt32(xf), Convert.ToInt32(f));
            // p2 = new Point(Convert.ToInt32(xf), Convert.ToInt32(f - fdata[i] * fyshift));
            //b = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, TColor);
            
            getcurrentandnextpoint(planOneDay,dataXunLian,out fdatanext);
            points1.Add(new PointF(xf, Convert.ToSingle(f - fdatanow * fyshift)));
            //Rectangle rectangle = new Rectangle(Convert.ToInt32(xf), Convert.ToInt32(f), Convert.ToInt32(fxshift), Convert.ToInt32(fdata[i]* fyshift));

            // points.Add(new PointF(xf, f));
            if ((fdatanext - 35) * (fdatanow - 35) < 0)
            {
                float ftemp = Convert.ToSingle(fxshift * (35f - fdatanow) / (fdatanext - fdatanow));
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fdatanow * fyshift)));
                points.Add(new PointF(xf + ftemp, Convert.ToSingle(f - 35 * fyshift)));
                points.Add(new PointF(xf + ftemp, f));
                if (fdatanow < 35)
                    graphics.FillPolygon(b2, points.ToArray());
                else
                    graphics.FillPolygon(b, points.ToArray());
                points = new List<PointF>();
                points.Add(new PointF(xf + ftemp, f));
                points.Add(new PointF(xf + ftemp, Convert.ToSingle(f - 35 * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fdatanext * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                if (fdatanext < 35)
                    graphics.FillPolygon(b2, points.ToArray());
                else
                    graphics.FillPolygon(b, points.ToArray());
            }
            else if (fdatanext < 35)
            {
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fdatanow * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fdatanext * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                graphics.FillPolygon(b2, points.ToArray());
            }
            else
            {
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fdatanow * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fdatanext * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                graphics.FillPolygon(b, points.ToArray());
            }
            //graphics.(b, points.ToArray());
            xf += fxshift;
            fdatanow = fdatanext;
        }
        pen = new Pen(Color.Black);
        graphics.DrawLines(pen, points1.ToArray());
        #endregion
        #region 坐标轴

        graphics.DrawLine(pen, f_ZeroX, f_ZeroY, f_ZeroX, f_ZeroY - f_Ylength);
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
        f -= f_Ylength * 0.35f;
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        graphics.DrawString("35", font, Brushes.Black, f_ZeroX - graphics.MeasureString("35", font).Width - 2, f - fntHeight / 2);
        f -= f_Ylength * 0.3f;
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        graphics.DrawString("65", font, Brushes.Black, f_ZeroX - graphics.MeasureString("65", font).Width - 2, f - fntHeight / 2);
        f -= f_Ylength * 0.35f;
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        graphics.DrawString("100", font, Brushes.Black, f_ZeroX - graphics.MeasureString("100", font).Width - 2, f - fntHeight / 2);
        f = f_ZeroY - f_Ylength * 0.18f - fntHeight * 0.4f;
        graphics.DrawString("走神", font, Brushes.Blue, f_ZeroX - graphics.MeasureString("走神", font).Width - 2, f);
        f = f_ZeroY - f_Ylength * 0.53f - fntHeight * 0.4f;
        graphics.DrawString("一般", font, Brushes.Orange, f_ZeroX - graphics.MeasureString("走神", font).Width - 2, f);
        f = f_ZeroY - f_Ylength * 0.83f - fntHeight * 0.4f;
        graphics.DrawString("忘我", font, Brushes.Red, f_ZeroX - graphics.MeasureString("走神", font).Width - 2, f);
        pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

        if (xiabiao > 60)
        {
            bMin = true;
            xiabiao = Convert.ToInt32(Math.Ceiling(xiabiao / 60f) * 60);
            xiabiaocount = iLenght / xiabiao;
        }
        if (Math.Abs(xiabiao * xiabiaocount - iLenght) > 0 && Math.Abs(xiabiao * xiabiaocount - iLenght) < xiabiao / 3)
            xiabiaocount--;


        f = f_ZeroY + fntHeight;
        xf = f_ZeroX;
        //graphics.DrawLine(pen, xf + fxshift, f_ZeroY, xf + fxshift, f_ZeroY + 3);
        //graphics.DrawString("0", font, Brushes.Red, xf , f);
        for (int i = 0; i <= xiabiaocount; i++)
        {

            int aa = bMin ? i * xiabiao / 60 : i * xiabiao;
            aa = sec ? aa : aa / 2;
            graphics.DrawLine(pen, xf, f_ZeroY, xf, f_ZeroY + 3);
            graphics.DrawString(aa.ToString(), font, Brushes.Red, xf - graphics.MeasureString(aa.ToString(), font).Width / 2, f - fntHeight * 2 / 3);
            xf += f_Xlength * xiabiao / iLenght;
        }
        #endregion
        pen = new Pen(Color.Black);
       // img.Save(@"F:\5.png", ImageFormat.Png);
        graphics.Dispose();
        return img;
    }
    public static Bitmap Getrect(double[] fdata, int count21)
    {
        int Xrange =1000, Yrange = 500;
        Font font = new Font("宋体", 18, FontStyle.Regular);
        int fntHeight = 28;
        Bitmap img = new Bitmap(Xrange, Yrange);
        float f_ZeroX = fntHeight * 5, f_ZeroY = Yrange - fntHeight * 3;
        float f_Xlength = Xrange - 2 * f_ZeroX, f_Ylength = Yrange - fntHeight * 6;
        Graphics graphics = Graphics.FromImage(img);

        graphics.Clear(Color.White);
        Pen pen = new Pen(Color.Black);
        float f = f_ZeroY;
        int iLenght = fdata.Length;
        int xiabiaocount = 7;
        int xiabiao = iLenght / xiabiaocount;
        float fEachpoint = f_Xlength / iLenght;
        bool bMin = false;
        float fxshift = fntHeight;
        float fyshift = fntHeight;
        float xf = f_ZeroX - fxshift;
        #region  画柱状图
        Color FColor = Color.White; //颜色1
        Color TColor = Color.Red;  //颜色2

        fxshift = f_Xlength / (iLenght - 1);
        xf = f_ZeroX;
        f = f_ZeroY;
        float fff = 100f;
        fyshift = f_Ylength / fff;
        List<PointF> points = new List<PointF>();
        List<PointF> points1 = new List<PointF>();
        pen = new Pen(Color.Empty);
        PointF p1 = new PointF(xf, f);
        PointF p2 = new PointF(xf, f - f_Ylength);
        PointF p3 = new PointF(xf, f - 35 * fyshift);
        Brush b = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, TColor);  //实例化刷子，第一个参数指示上色区域，第二个和第三个参数分别渐变颜色的开始和结束，第四个参数表示颜色的方向。
        Brush b2 = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, Color.Gray);
        for (int i = 0; i < iLenght - 1; i++)
        {
            // p1 = new Point(Convert.ToInt32(xf), Convert.ToInt32(f));
            // p2 = new Point(Convert.ToInt32(xf), Convert.ToInt32(f - fdata[i] * fyshift));
            //b = new System.Drawing.Drawing2D.LinearGradientBrush(p1, p2, FColor, TColor);
            points1.Add(new PointF(xf, Convert.ToSingle(f - fdata[i] * fyshift)));
            //Rectangle rectangle = new Rectangle(Convert.ToInt32(xf), Convert.ToInt32(f), Convert.ToInt32(fxshift), Convert.ToInt32(fdata[i]* fyshift));

            // points.Add(new PointF(xf, f));
            if ((fdata[i + 1] - 35) * (fdata[i] - 35) < 0)
            {
                float ftemp = Convert.ToSingle(fxshift * (35f - fdata[i]) / (fdata[i + 1] - fdata[i]));
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fdata[i] * fyshift)));
                points.Add(new PointF(xf + ftemp, Convert.ToSingle(f - 35 * fyshift)));
                points.Add(new PointF(xf + ftemp, f));
                if (fdata[i] < 35)
                    graphics.FillPolygon(b2, points.ToArray());
                else
                    graphics.FillPolygon(b, points.ToArray());
                points = new List<PointF>();
                points.Add(new PointF(xf + ftemp, f));
                points.Add(new PointF(xf + ftemp, Convert.ToSingle(f - 35 * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fdata[i + 1] * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                if (fdata[i + 1] < 35)
                    graphics.FillPolygon(b2, points.ToArray());
                else
                    graphics.FillPolygon(b, points.ToArray());
            }
            else if (fdata[i + 1] < 35)
            {
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fdata[i] * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fdata[i + 1] * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                graphics.FillPolygon(b2, points.ToArray());
            }
            else
            {
                points = new List<PointF>();
                points.Add(new PointF(xf, f));
                points.Add(new PointF(xf, Convert.ToSingle(f - fdata[i] * fyshift)));
                points.Add(new PointF(xf + fxshift, Convert.ToSingle(f - fdata[i + 1] * fyshift)));
                points.Add(new PointF(xf + fxshift, f));
                graphics.FillPolygon(b, points.ToArray());
            }

            //graphics.(b, points.ToArray());
            xf += fxshift;
        }
        pen = new Pen(Color.Black);
        graphics.DrawLines(pen, points1.ToArray());
        #endregion
        #region 坐标轴

        graphics.DrawLine(pen, f_ZeroX, f_ZeroY, f_ZeroX, f_ZeroY - f_Ylength);
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
        f -= f_Ylength * 0.35f;
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        graphics.DrawString("35", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
        f -= f_Ylength * 0.3f;
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        graphics.DrawString("65", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
        f -= f_Ylength * 0.35f;
        graphics.DrawLine(pen, f_ZeroX, f, f_ZeroX + f_Xlength, f);
        graphics.DrawString("100", font, Brushes.Black, f_ZeroX - fntHeight * 2, f - fntHeight / 2);
        f = f_ZeroY - f_Ylength * 0.18f - fntHeight * 0.4f;
        graphics.DrawString("走神", font, Brushes.Blue, f_ZeroX - graphics.MeasureString("走神", font).Width - 2, f);
        f = f_ZeroY - f_Ylength * 0.53f - fntHeight * 0.4f;
        graphics.DrawString("一般", font, Brushes.Orange, f_ZeroX - graphics.MeasureString("走神", font).Width - 2, f);
        f = f_ZeroY - f_Ylength * 0.83f - fntHeight * 0.4f;
        graphics.DrawString("忘我", font, Brushes.Red, f_ZeroX - graphics.MeasureString("走神", font).Width - 2, f);
        pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;


        if (Math.Abs(xiabiao * xiabiaocount - iLenght) > 0 && Math.Abs(xiabiao * xiabiaocount - iLenght) < xiabiao / 3)
            xiabiaocount--;


        f = f_ZeroY + fntHeight;
        xf = f_ZeroX;
        //graphics.DrawLine(pen, xf + fxshift, f_ZeroY, xf + fxshift, f_ZeroY + 3);
        //graphics.DrawString("0", font, Brushes.Red, xf , f);
        for (int i = 0; i <= xiabiaocount; i++)
        {

            graphics.DrawLine(pen, xf, f_ZeroY, xf, f_ZeroY + 3);
            graphics.DrawString((i * xiabiao).ToString(), font, Brushes.Red, xf - graphics.MeasureString((i * xiabiao).ToString(), font).Width / 2, f - fntHeight * 2 / 3);
            xf += f_Xlength * xiabiao / iLenght;
        }
        #endregion
        pen = new Pen(Color.Black);
        //img.Save(@"F:\5.png", ImageFormat.Png);
        graphics.Dispose();
        return img;
    }
    //private SharpMap.Styles.VectorStyle GetCustomStyle(FeatureDataRow row)
    //{
    //    SharpMap.Styles.VectorStyle style = new SharpMap.Styles.VectorStyle();
    //    Color color1 = 需要绘制的起始颜色;
    //    Color color2 = 需要绘制的终止颜色;
    //    //通过两点来确定渐变色的方向，此处需要将地理坐标转换为屏幕坐标赋给LinearGradientBrush. 
    //    PointF point1 = mapBox1.Map.WorldToImage(row.Geometry.Coordinates[0]);
    //    PointF point2 = mapBox1.Map.WorldToImage(row.Geometry.Coordinates[2]);
    //    System.Drawing.Drawing2D.LinearGradientBrush lineGrBrush = new System.Drawing.Drawing2D.LinearGradientBrush(point1, point2, color1, color2);
    //    style.Fill = lineGrBrush;
    //    style.Line.Color = Color.White;
    //    return style;
    //}
}
//}
